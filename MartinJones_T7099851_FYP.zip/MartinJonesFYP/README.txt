What is this

This project was made for developing an ai that uses a point of interest system so that the ai units can make decision for themselves in a designated spot. The intent was to make ai seem more alive for strategy games so they don't just stand still in spot or follow a target too far like the end of the map. The ai can engage close enemies when at an advantage and back up allies if at a disadvantage. If cover is nearby the ai will try to take advantage of the defensive cover if it isn't already being used by an enemy. The ai will also run away if at a massive disadvantage but won't run away too far so a player can still keep track of the unit.

Controls

left click on a player unit to select it.

right click to move selected units to where the mouse is pointing.

right click on an enemy and selected units will keep moving to engage that enemy.

right click an ally unit and selected units will follow and assist that unit.

(In Unity Editor Only with gizmos on)

Left click an enemy to see points of interest they are taking note of.

Units selected when playing in unity editor will display their points of interest.