﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class cover : MonoBehaviour
{
    public bool isInPoint = false;
    public float defenseLevel;
    public float defenseAreaSize;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
